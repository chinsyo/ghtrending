# GHTRENDING

## INTRO

**GHTRENDING** is a commandline tool to view github trending, include developers and repository.

![help](./screenshot/help.png)
![repository](./screenshot/repository.png)
![developers](./screenshot/developers.png)

## USAGE

    python3 ghtrending.py

## TODO

* ~~install via pip~~


